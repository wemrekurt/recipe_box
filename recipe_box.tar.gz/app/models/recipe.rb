class Recipe < ActiveRecord::Base
end
